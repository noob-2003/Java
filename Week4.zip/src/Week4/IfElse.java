package Week4;

public class IfElse {
	public static void main(String[] args) {
		int score = 85;
		
		// 이상, 이하 : >=, <=
		// 초과, 미만 : > , <
		if (score >= 90) {
			System.out.println("90점 이상");
			System.out.println("A등급");
		}
		else {
			System.out.println("90점 미만");
			System.out.println("B등급");
		}
	}
}
