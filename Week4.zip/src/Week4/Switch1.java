package Week4;

public class Switch1 {
	public static void main(String[] args) {
		char grade = 'A';
		
		switch(grade) {
		case 'A':
			System.out.println("A등급");
			break;
		case 'B':
			System.out.println("B등급");
			break;
		default:
			System.out.println("기타 등급");
		}
	}
}
