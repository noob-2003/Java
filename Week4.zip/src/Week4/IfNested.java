package Week4;

public class IfNested {
	public static void main(String[] args) {
		// 랜덤 함수 이용해 0 ~ 100 사이 점수 생성
		int score = (int)(Math.random() * 100);
		System.out.println("점수 = " + score);
		String grade;
		
		if (score >= 90) {
			if (score > 95)
				grade = "A+";
			else if (score > 93)
				// 93 < score <= 95
				grade = "A0";
			else
				// 90 <= score <= 93
				grade = "A-";
		}
		else if (score >= 80) {
			if (score > 85)
				grade = "B+";
			else if (score > 83)
				grade = "B0";
			else
				grade = "B-";
		}
		else
			grade = "C";
		System.out.println("등급 = " + grade);
	}
}
