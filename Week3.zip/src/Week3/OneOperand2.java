package Week3;

public class OneOperand2 {
	public static void main(String[] args) {
		// 단항 연산자 : 증감 연산자 (++, --)		
		int x = 10;
		int y = 10;
		int z;
		
		// ++ 연산자 : 피연산자의 기존 값에 1을 더한다
		// ++ 연산이 전위 연산자인 경우 먼저 변수에 1을 더하고 명령을 실행한다
		System.out.println("++x = " + ++x); // x = 11
		
		// ++ 연산이 후위 연산자인 경우 명령을 먼저 실행하고 변수에 1을 더한다
		System.out.println("x++ = " + x++); // x = 11
		System.out.println("x = " + x); 	// x = 12
		
		z = x++;
		System.out.println("z = " + z);
		System.out.println("x = " + x);
		
		z = ++x + y--; // z = 14 + 10 = 24
		System.out.println("z = " + z);
		System.out.println("x = " + x);
		System.out.println("y = " + y);
	}
}
