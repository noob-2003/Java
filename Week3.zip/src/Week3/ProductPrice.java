package Week3;

public class ProductPrice {
	public static void main(String[] args) {
		int milkPrice = 4500;
		int milkNum = 1;
		
		int carrotPrice = 1000;
		int carrotNum = 3;
		
		int snackPrice = 1500;
		int snackNum = 2;
		
		int totalPrice = milkPrice * milkNum + carrotPrice * carrotNum + snackPrice * snackNum;
		System.out.printf("할인 전 상품 가격 : %d원\n", totalPrice);
		
		double salePrice = (double) totalPrice * 0.1;
		System.out.printf("할인 금액 : %.1f원\n", salePrice);
		
		System.out.printf("최종 결제 금액 : %.1f원\n", (totalPrice - salePrice));
	}
}
