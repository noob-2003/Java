package Week2;

public class DataType1 {
	public static void main(String[] args) {
		// 기본 데이터 타입
		// 직접 값을 주는 초기값 == 리터럴
		
		// 정수형
		byte bData = 65; // 1 Byte
		char cData = 65; // 2 Byte
		short sData = 65;// 2 Byte
		int iData = 65;	 // 4 Byte
		long lData = 65; // 8 Byte
		
		// 실수형
		float fData = 65.12f; // 4 Byte
		double dData = 65.12; // 8 Byte
		
		boolean boolData = true; // 1 Byte
		
		System.out.println("bData = " + bData);
		System.out.println("cData = " + cData);
		System.out.println("sData = " + sData);
		System.out.println("iData = " + iData);
		System.out.println("lData = " + lData);
		System.out.println("fData = " + fData);
		System.out.println("dData = " + dData);
		System.out.println("boolData = " + boolData);
	}
}
