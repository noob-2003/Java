package Week2;

public class PersonInfo {
	public static void main(String[] args) {
		String name = "정민재";
		int age = 23;
		double height = 170.1;
		char gender = 'M';
		boolean student = true;
		
		System.out.println("이름: " + name);
		System.out.println("나이: " + age + "세");
		System.out.println("키: " + height + "cm");
		System.out.println("성별: " + gender);
		System.out.println("학생 여부: " + student);
	}
}
