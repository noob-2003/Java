package Week2;

public class DataType4 {
	public static void main(String[] args) {
		// 1 byte (-128 ~ 127)
		byte bData = 127;
		
		// char 자료형은 음수가 없다
		char cData = 90;
		
		// 실수형은 기본이 double
		float fData = 3.14f;
		
		// 정수형은 기본이 int
		long lData = 10000000000L;
		
		// boolean은 true or false
		boolean boolD = true;
		
		System.out.println("bData = " + bData);
		System.out.println("cData = " + cData);
		System.out.println("fData = " + fData);
		System.out.println("lData = " + lData);
		System.out.println("boolD = " + boolD);
	}
}
